SLStudio.Utils.RemoveHighlighting(get_param('MVDR4x4HDL','Handle'));
