SLStudio.Utils.RemoveHighlighting(get_param('MVDR4x4HDL', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_MVDR4x4HDL', 'handle'));
annotate_port('gm_MVDR4x4HDL/MVDR_QLess_HDL/Form Beam/Tree Sum', 0, 1, '');
annotate_port('MVDR4x4HDL/MVDR_QLess_HDL/Form Beam/Tree Sum', 0, 1, '');
annotate_port('gm_MVDR4x4HDL/MVDR_QLess_HDL/Normalize Response/MVDR Weight Update/Inner Product', 0, 1, '');
annotate_port('MVDR4x4HDL/MVDR_QLess_HDL/Normalize Response/MVDR Weight Update/Inner Product', 0, 1, '');
annotate_port('gm_MVDR4x4HDL/MVDR_QLess_HDL/Normalize Response/MVDR Weight Update/Inner Product/Tree Sum with Distributed Pipelining', 0, 1, '');
annotate_port('MVDR4x4HDL/MVDR_QLess_HDL/Normalize Response/MVDR Weight Update/Inner Product/Tree Sum with Distributed Pipelining', 0, 1, '');
